<?php
require_once(dirname(__FILE__).'/recaptcha.class.php');
require_once(dirname(__FILE__).'/recaptcha.user.lib.php');
?>